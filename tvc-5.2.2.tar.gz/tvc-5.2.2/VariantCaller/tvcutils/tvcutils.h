/* Copyright (C) 2013 Ion Torrent Systems, Inc. All Rights Reserved */

#ifndef TVCUTILS_H
#define TVCUTILS_H

int PrepareHotspots(int argc, const char *argv[]);
int ValidateBed(int argc, const char *argv[]);
int UnifyVcf(int argc, const char *argv[]);
int SplitVcf(int argc, const char *argv[]);

#endif // TVCUTILS_H
